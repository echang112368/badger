from django.db import models
from django.contrib.auth import get_user_model

User = get_user_model()

class MerchantCreatorLink(models.Model):
    merchant = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'is_merchant': True})
    creator = models.ForeignKey(User, on_delete=models.CASCADE, limit_choices_to={'is_creator': True})

    def __str__(self):
        return f"{self.creator.username} linked to {self.merchant.username}"