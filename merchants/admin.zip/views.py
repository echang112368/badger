from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import ContentCreatorActivity

@login_required
def merchant_dashboard(request):
    if not request.user.is_merchant:
        return render(request, '403.html')  # Unauthorized

    # Get all unique creators for this merchant
    activities = ContentCreatorActivity.objects.filter(merchant=request.user).select_related('creator')
    unique_creators = {activity.creator for activity in activities}

    return render(request, 'merchants/dashboard.html', {
        'merchant': request.user,
        'creators': unique_creators
    })
