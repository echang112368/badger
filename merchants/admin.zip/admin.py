
from django.contrib import admin
from .models import MerchantCreatorLink

@admin.register(MerchantCreatorLink)
class MerchantCreatorLinkAdmin(admin.ModelAdmin):
    list_display = ('merchant', 'creator')
    search_fields = ('merchant__username', 'creator__username')